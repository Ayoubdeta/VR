using UnityEngine;

public class AttachToPalet : MonoBehaviour
{
    private Rigidbody rb;
    private bool isAttached = false;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (!isAttached && collision.gameObject.CompareTag("Palett"))
        {
            // Esperar un pequeño tiempo para asegurar que la caja está estable antes de fijarla
            Invoke(nameof(AttachToPallet), 0.1f);
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (isAttached && collision.gameObject.CompareTag("Palett"))
        {
            DetachFromPallet();
        }
    }

    private void AttachToPallet()
    {
        // Asegurar que sigue tocando el palet antes de fijarla
        if (!isAttached && CheckIfOnPallet())
        {
            rb.useGravity = false;
            rb.linearVelocity = Vector3.zero; // Corregido de linearVelocity
            rb.angularVelocity = Vector3.zero;
            rb.isKinematic = true;
            transform.SetParent(FindClosestPallet().transform); // Se fija al palet más cercano
            isAttached = true;
        }
    }

    private void DetachFromPallet()
    {
        rb.useGravity = true;
        rb.isKinematic = false;
        transform.SetParent(null);
        isAttached = false;
    }

    private bool CheckIfOnPallet()
    {
        // Revisar si hay un palet debajo de la caja usando un Raycast
        RaycastHit hit;
        if (Physics.Raycast(transform.position, Vector3.down, out hit, 0.5f))
        {
            return hit.collider.CompareTag("Palett");
        }
        return false;
    }

    private GameObject FindClosestPallet()
    {
        GameObject[] pallets = GameObject.FindGameObjectsWithTag("Palett");
        GameObject closest = null;
        float minDistance = Mathf.Infinity;

        foreach (GameObject pallet in pallets)
        {
            float distance = Vector3.Distance(transform.position, pallet.transform.position);
            if (distance < minDistance)
            {
                minDistance = distance;
                closest = pallet;
            }
        }

        return closest;
    }
}

