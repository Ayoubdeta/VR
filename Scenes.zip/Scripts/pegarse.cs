using UnityEngine;

public class StickObjectsOptimized : MonoBehaviour
{
    private bool isAttached = false; // Para evitar múltiples asignaciones innecesarias

    private void OnTriggerEnter(Collider other)
    {
        if (!isAttached && other.CompareTag("Objeto2"))
        {
            other.transform.SetParent(transform);
            other.attachedRigidbody.isKinematic = true; // Desactiva la física para evitar problemas
            isAttached = true; // Evita llamadas repetidas
        }
    }
}